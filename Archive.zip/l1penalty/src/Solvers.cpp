#include "../include/Solvers.hpp"
#include <Eigen/Dense>
#include <cmath>
#include <iostream>
#include <limits>
#include <tuple>
#include <vector>

// Definition
